package com.ryan.safetynet.alerts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlertsApplicationTests {

	@Test
	void contextLoads() {
	}

}
